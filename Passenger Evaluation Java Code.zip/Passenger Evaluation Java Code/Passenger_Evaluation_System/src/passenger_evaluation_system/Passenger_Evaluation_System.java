
package passenger_evaluation_system;

import java.awt.Dimension;
import java.awt.Toolkit;


public class Passenger_Evaluation_System {

    public static void main(String[] args) 
    {
       Login_Frame lf=new Login_Frame();
       Dimension d=Toolkit.getDefaultToolkit().getScreenSize();
       lf.setVisible(true);
       lf.setSize(d);
    }
    
}
