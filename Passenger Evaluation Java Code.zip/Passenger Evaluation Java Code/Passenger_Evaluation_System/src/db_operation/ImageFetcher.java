/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db_operation;

import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author welcome
 */
public class ImageFetcher
{ public ArrayList getData(Statement st,String sid)
    {
        ArrayList data=new ArrayList();
        try
        {
            String query="select * from passenger_info where student_id='"+sid+"'";
            ResultSet rs=st.executeQuery(query);
            while(rs.next())
            {   
                Blob b1 = rs.getBlob("captured_image");
                byte barr1[]=b1.getBytes(1,(int)b1.length());
                data.add(barr1);
            }
            System.out.println("Data is: "+data);
        }
        catch(Exception ex)
        {
            System.out.println("Exception is: "+ex);
        }
        return data;
    }
    
}
