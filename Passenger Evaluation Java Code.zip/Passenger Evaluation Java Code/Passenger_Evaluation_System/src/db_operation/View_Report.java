/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db_operation;

import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author welcome
 */
public class View_Report
{
    
    String getcolumnName(ArrayList hcl,String userdata)
    {
        String columname="";
        for (int i = 0; i < hcl.size(); i++) 
        {
            ArrayList temp=(ArrayList)hcl.get(i);
            String attributename=(String)temp.get(0);
            String column=(String)temp.get(1);
            if(userdata.equals(attributename))
            {
                columname=column;
                break;
                
            }
            
        }
        return columname;
    }
    
    
    
    
    
     public ArrayList getViewData(ArrayList search_from_data,ArrayList search_by_data)
    {
        ArrayList data=new ArrayList();
        try
        {
             System.out.println("Search form :");
            Statement st1=new DBDriver().getStatement();
          
            for (int i = 0; i < search_from_data.size(); i++)
            {
                ArrayList temp=(ArrayList) search_from_data.get(i);
                //System.out.println(temp);
            }
            System.out.println("Search by :");
            String query="select * from passenger_info where ";
             for (int i = 0; i < search_by_data.size(); i++)
            {
                ArrayList temp=(ArrayList) search_by_data.get(i);
               // System.out.println(temp);
               String attribute=(String)temp.get(0);
               String value=(String)temp.get(1);
               String columnname=getcolumnName(search_from_data,attribute);
               System.out.println(columnname+" --  "+value);
               query=query+columnname+"='"+value+"' and ";
               
            }
             query=query.substring(0, query.length()-4);
             //route_num, veihicle_num, driver_name, driver_num, student_id, student_name, reported_date, reported_time, captured_image
//             System.out.println("Formed Query is "+query);
//             String route_num="34",veihicle_num="MH12GE5902",reported_date="30/12/2023";
//             String query1="select * from passenger_info where route_num='"+route_num+"' and veihicle_num='"+veihicle_num+"' and reported_date='"+reported_date+"'";
//             
//             System.out.println("Ready Query "+query1);
             
          
            
            ResultSet rs1=st1.executeQuery(query);
          
            while(rs1.next())
            {
                ArrayList in=new ArrayList();
                String routeno=rs1.getString(1);
                String busno=rs1.getString(2);
                String drivername=rs1.getString(3);
                String mobile=rs1.getString(4);
                String studid=rs1.getString(5);
                String studname=rs1.getString(6);
                String date=rs1.getString(7);
                String time=rs1.getString(8);
                in.add(routeno);
                in.add(busno);
                in.add(drivername);
                in.add(mobile);
                in.add(studid);
                in.add(studname);
                in.add(date);
                in.add(time);
                data.add(in);
                  
            }
            
        }
        catch(Exception ex)
        {
            System.out.println("Exception is: "+ex);
        }
        return data;
    }
}
