/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db_operation;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author welcome
 */
public class For_Search 
{
  
    public ArrayList getData_ForSearch(Statement st,String user_val)
    {
        ArrayList data=new ArrayList();
        ArrayList unique_data=new ArrayList();
        try
        {
            String query="select * from passenger_info";
            ResultSet rs=st.executeQuery(query);
            while(rs.next())
            {
                if(user_val.equals("Route Number"))
                {
                     String value=rs.getString(1);
                    data.add(value);       
                }
                if(user_val.equals("Bus Number"))
                {
                     String value=rs.getString(2);
                    data.add(value);       
                }
                if(user_val.equals("Driver Name"))
                {
                     String value=rs.getString(3);
                    data.add(value);       
                }
                if(user_val.equals("Student Id"))
                {
                     String value=rs.getString(5);
                    data.add(value);       
                }
                if(user_val.equals("Student Name"))
                {
                     String value=rs.getString(6);
                    data.add(value);       
                }
                if(user_val.equals("Date"))
                {
                     String value=rs.getString(7);
                    data.add(value);       
                }
            }
            
       
        for (int i = 0; i < data.size(); i++)
        {
          String ele=(String)data.get(i);
          if(!unique_data.contains(ele))
              unique_data.add(ele);
        }
        }
        catch(Exception ex)
        {
            System.out.println("Exception is: "+ex);
        }
        return unique_data;
    }
}
