/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db_operation;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author welcome
 */
public class DateFetcher 
{
     public ArrayList getData(Statement st)
    {
        ArrayList data=new ArrayList();
         ArrayList passenger_unique_date=new ArrayList();
        try
        {
            String query="select * from passenger_info ";
            ResultSet rs=st.executeQuery(query);
            while(rs.next())
            {  
                data.add(rs.getString(6));
               
            }
           
            for (int i = 0; i < data.size(); i++)
            {
                String ele=(String)data.get(i);
                if(!passenger_unique_date.contains(ele))
                    passenger_unique_date.add(ele);
            }
            System.out.println("Data is: "+passenger_unique_date);
        }
        catch(Exception ex)
        {
            System.out.println("Exception is: "+ex);
        }
        return passenger_unique_date;
    }
}
