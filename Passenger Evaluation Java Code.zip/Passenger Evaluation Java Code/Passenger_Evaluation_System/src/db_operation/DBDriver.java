/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db_operation;

import java.sql.*;

/**
 *
 * @author lenovo
 */
public class DBDriver 
{
    public Statement getStatement()
    {
        Statement st=null;
        try
        {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/passenger_evaluation","root","root");
            st=(Statement)  con.createStatement();
             
             
        }
         catch(Exception e)
             {
                 System.out.println("Exeption in DB Class is: "+e);
             }
            
        return st;
    }
    
    
}
