from tkinter import *
import tkinter as tk
from PIL import Image, ImageTk
import Passenger_Evaluation_Engine


def center_window(w,h):
    # get screen width and height
    ws = root.winfo_screenwidth()
    hs = root.winfo_screenheight()
    # calculate position x, y
    x = (ws/2) - (w/2)    
    y = (hs/2) - (h/2)
    root.geometry('%dx%d+%d+%d' % (w, h, x, y))
    
def read_input():
    route_num=textBox1.get()
    vehicle_numb=textBox2.get()
    driver_name=textBox3.get()
    driver_contact=textBox4.get()
  
    print("route_num = ",route_num)
    print("vehicle_numb = ",vehicle_numb)
    print("driver_name = ",driver_name)
    print("driver_contact = ",driver_contact)
    
    Passenger_Evaluation_Engine.initEvaluationEngine(route_num,vehicle_numb,driver_name,driver_contact)
    
   
   
    

    
root=Tk()
root.configure(background='#6495ED')
root.title("PASSENGER EVALUATION SYSTEM FOR COLLEGE BUS")
center_window(1400, 800)
image = Image.open("model/main_image.jpg")

# Resize the image using resize() method
resize_image = image.resize((1600, 1000))

img = ImageTk.PhotoImage(resize_image)

# create label and add resize image
label1 = Label(image=img)
label1.image = img
label1.pack()


username = Label(root,text = "PASSENGER EVALUATION SYSTEM ", font=("Courier", 30,'bold'),fg='#f00',bg='#6495ED').place(x = 350,y = 60)


# code to create label 

label1 = Label(root,text = "ROUTE NUMBER: ",bg='#6495ED',font=("Ariel", 10)).place(x = 400,y = 205)
label2 = Label(root, text = "VEHICLE NUMBER : ",bg='#6495ED',font=("Ariel", 10)).place(x = 400,y = 265)  
label3 = Label(root, text = "DRIVER NAME: ",bg='#6495ED',font=("Ariel", 10)).place(x = 400,y = 325)    
label4 = Label(root, text = "DRIVER CONTACT No.: ",bg='#6495ED',font=("Ariel", 10)).place(x = 400,y = 385)  

#code to insert textbox
textBox1 = tk.Entry(root, width = 40)
textBox1.place(x = 625,y = 200,height=30)

textBox2 = Entry(root, width = 40)
textBox2.place(x = 625,y = 260,height=30)

textBox3 = Entry(root, width = 40)
textBox3.place(x = 625,y = 320,height=30)

textBox4 = Entry(root, width = 40)
textBox4.place(x = 625,y = 380,height=30)




#command=lambda: retrieve_input() >>> just means do this when i press the button
button=Button(root, height=1, width=13, font=("Ariel", 10,'bold'),text="Submit", command=lambda: read_input()).place(x=530,y=460)
# Button for closing
exit_button = Button(root, height=1, width=13, font=("Ariel", 10,'bold'),text="Exit", command=root.destroy).place(x=700,y=460)


mainloop()

