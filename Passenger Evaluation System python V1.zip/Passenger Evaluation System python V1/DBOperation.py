import mysql.connector


#route_num, veihicle_num, driver_name, driver_num, student_id, student_name, reported_date, reported_time, captured_image
def getInsertImageInfo(route_num,vehicle_numb, driver_name, driver_contact, student_id, student_name, current_date, current_time, file):
    
    flag=False
    try:
        connection=mysql.connector.connect(host='localhost',database='passenger_evaluation',user='root',password='root')
        cursor=connection.cursor()
 
        sql_insert_blob_query = """ INSERT INTO passenger_info
        (route_num,veihicle_num, driver_name, driver_num, student_id, student_name,reported_date,reported_time,captured_image) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s) """
        insert_blob_tuple = (route_num,vehicle_numb,driver_name,driver_contact,student_id,student_name,current_date,current_time,file) # formal parameters
        result = cursor.execute(sql_insert_blob_query, insert_blob_tuple)
        connection.commit()
        flag=True

        print("Image and file inserted successfully as a BLOB into python_employee table", result)
    except mysql.connector.Error as error:
        print("Failed inserting BLOB data into MySQL table {}".format(error))

    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()
    return flag









