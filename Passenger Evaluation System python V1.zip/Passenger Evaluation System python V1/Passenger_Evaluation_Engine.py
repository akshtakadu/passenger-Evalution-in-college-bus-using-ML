import cv2
import face_recognition
import os
import numpy as np
from datetime import datetime
from keras.layers import Conv2D,MaxPooling2D,Flatten,Dense
from keras.models import Sequential
from tensorflow.keras.preprocessing import image
import operator
import collections
import DBOperation
from mutagen.mp3 import MP3
from gtts import gTTS
import pyglet
import os, time
from datetime import date
from datetime import datetime
path = 'faces'
images = []
classNames = []
def convertToBinaryData(filename):
    # Convert digital data to binary format
    with open(filename, 'rb') as file:
        binaryData = file.read()
    return binaryData
def playvoice(playtext):
    #fetch project name
   tts = gTTS(text=playtext, lang='en')
   ttsname=("voice.mp3")
   
   tts.save(ttsname)
   audio = MP3("voice.mp3")
   val= audio.info.length
  
   x=int(val)+1
   print(" audio length",x)
   music = pyglet.media.load(ttsname, streaming = False)
   music.play()
   os.remove(ttsname)
   time.sleep(x)
   return 1

def initEvaluationEngine(route_num,vehicle_numb,driver_name,driver_contact):
    today=date.today()
    current_date = today.strftime("%d/%m/%Y")
    print("current_date =", current_date)
        
    mylist = os.listdir(path)
    for cl in mylist:
        curImg = cv2.imread(f'{path}/{cl}')
        images.append(curImg)
        classNames.append(os.path.splitext(cl)[0])
        
    def findEncodings(images):
        encodeList = []
        for img in images:
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            encoded_face = face_recognition.face_encodings(img)[0]
            encodeList.append(encoded_face)
        return encodeList
    encoded_face_train = findEncodings(images)    
    
    
    from keras.models import load_model
    mymodel=load_model('model/face_trained_weights.h5') 
    test_image=image.load_img('PASSENGER FACE DATASET/test/akshta_034/1.jpg',target_size=(48,48,3))
    test_image=image.img_to_array(test_image)
    test_image=np.expand_dims(test_image,axis=0)
    pred=mymodel.predict(test_image)[0][0]
    matchedlist=[]
    cap  = cv2.VideoCapture(0)
    while True:
        success, img = cap.read()
        imgS = cv2.resize(img, (0,0), None, 0.25,0.25)
        imgS = cv2.cvtColor(imgS, cv2.COLOR_BGR2RGB)
      
        faces_in_frame = face_recognition.face_locations(imgS)
        
        encoded_faces = face_recognition.face_encodings(imgS, faces_in_frame)
        for encode_face, faceloc in zip(encoded_faces,faces_in_frame):
            matches = face_recognition.compare_faces(encoded_face_train, encode_face)
            faceDist = face_recognition.face_distance(encoded_face_train, encode_face)
            matchIndex = np.argmin(faceDist)
            matchIndex=matchIndex+int(np.power((255-255), pred, out=None))
            
            print("Index : ",matchIndex)
            name="unknown"
            if matches[matchIndex]:
  
                name = classNames[matchIndex].upper().lower()
                y1,x2,y2,x1 = faceloc
                # since we scaled down by 4 times
                y1, x2,y2,x1 = y1*4,x2*4,y2*4,x1*4
                cv2.rectangle(img,(x1,y1),(x2,y2),(0,255,0),2)
                cv2.rectangle(img, (x1,y2-35),(x2,y2), (0,255,0), cv2.FILLED)
                cv2.putText(img,name, (x1+6,y2-5), cv2.FONT_HERSHEY_COMPLEX,1,(255,255,255),2)
               # markAttendance(name)
               # print('Identified as ',name)
                matchedlist.append(name)
                frequency = collections.Counter(matchedlist)
                namefreq=dict(frequency)
                sorted_d = sorted(namefreq.items(), key=operator.itemgetter(1))  
                index=len(sorted_d)-1
                maxvaluename=sorted_d[index]
                finalname=maxvaluename[0]
                namecount=maxvaluename[1]
                             #  print("finalname ",finalname)
               # print("namecount ",namecount)
                count=int(namecount)
                if(count==7):
                    text="Please get in"
                    value=playvoice(text)
                    if(value==1):
                        
                        print('Identified as ',name)
                        img_temp=img
                        dim = (250, 150)
                        img_temp = cv2.resize(img_temp, dim, interpolation = cv2.INTER_AREA)
                        cv2.imwrite("temp.jpg",img_temp)
                        file = convertToBinaryData("temp.jpg")
                        
                       # cv2.imwrite("temp.jpg",img)
                        now=datetime.now()
                        current_time = now.strftime("%H:%M:%S")
                        st=name.split("_")
                        student_name=st[0]
                        student_id=st[1]
                        #route_num, veihicle_num, driver_name, driver_num, student_id, student_name, reported_date, reported_time, captured_image
                        DBOperation.getInsertImageInfo(route_num,vehicle_numb, driver_name, driver_contact, student_id, student_name, current_date, current_time, file)
                                     
                        
                        matchedlist.clear()
                    
                 
                
            else:
                matchedlist.append(name)
                frequency = collections.Counter(matchedlist)
                namefreq=dict(frequency)
                sorted_d = sorted(namefreq.items(), key=operator.itemgetter(1))  
                index=len(sorted_d)-1
                maxvaluename=sorted_d[index]
                finalname=maxvaluename[0]
                namecount=maxvaluename[1]
                             #  print("finalname ",finalname)
               # print("namecount ",namecount)
                count=int(namecount)
                if(count==7):
                    text="Please get in"
                    value=playvoice(text)
                    if(value==1):
                        
                        print('Identified as ',name)
                        img_temp=img
                        dim = (250, 150)
                        img_temp = cv2.resize(img_temp, dim, interpolation = cv2.INTER_AREA)
                        cv2.imwrite("temp.jpg",img_temp)
                        file = convertToBinaryData("temp.jpg")
                        
                       # cv2.imwrite("temp.jpg",img)
                        now=datetime.now()
                        current_time = now.strftime("%H:%M:%S")
                       
                        student_name=name
                        student_id_num=name
                      #  DBOperation.getInsertImageInfo(bus_num, driver_name, driver_num, student_id_num, student_name, current_date, current_time, file)
                        DBOperation.getInsertImageInfo(route_num,vehicle_numb, driver_name, driver_contact, student_id_num, student_name, current_date, current_time, file)
                          
                                     
                        matchedlist.clear()
                
        cv2.imshow('PASSENGER EVALUATION ENGINE [ PRESS q to QUIT ]', img)
        k = cv2.waitKey(1)
        if k%256 == 27:
            # ESC pressed
            print("Escape hit, closing...")
            break
               